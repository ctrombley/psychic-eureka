# psychic-eureka

Project description goes here

## Running the tests

```
make test
```

## Deployment

TBD

## Building

```
make
```

Binaries are cross-compiled for linux & darwin & written to `/dist`.

### Build targets

```
# Build without publishing
make snapshot

# Run the tests
make test
```

## Developing
Using Docker:
```
make

```
